{{- define "model-proxy.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "model-proxy.fullname" -}}
{{/* Reserve eight characters for the cleanup CronJob's 52-character name limit. */}}
{{- default (printf "%s-%s" .Release.Name (include "model-proxy.name" .)) .Values.fullnameOverride | trunc 44 | trimSuffix "-" -}}
{{- end -}}

{{- define "model-proxy.selectorLabels" -}}
app.kubernetes.io/name: {{ include "model-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/component: proxy
{{- end -}}

{{- define "model-proxy.labels" -}}
app.kubernetes.io/name: {{ include "model-proxy.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" | trimSuffix "." | trimSuffix "_" | quote }}
{{- end -}}

{{- define "model-proxy.image" -}}
{{- if .Values.image.digest -}}
{{ printf "%s@%s" .Values.image.repository .Values.image.digest }}
{{- else -}}
{{ printf "%s:%s" .Values.image.repository (default .Chart.AppVersion .Values.image.tag) }}
{{- end -}}
{{- end -}}

{{- define "model-proxy.databaseEnv" -}}
- name: MODEL_PROXY_DATABASE_DSN
  valueFrom:
    secretKeyRef:
      name: {{ .Values.secrets.existingSecret | quote }}
      key: {{ .Values.secrets.databaseDSNKey | quote }}
{{- end -}}

{{- define "model-proxy.jobPod" -}}
restartPolicy: Never
automountServiceAccountToken: false
{{- with .Values.imagePullSecrets }}
imagePullSecrets:
  {{- toYaml . | nindent 2 }}
{{- end }}
securityContext:
  {{- toYaml .Values.podSecurityContext | nindent 2 }}
{{- with .Values.nodeSelector }}
nodeSelector:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.tolerations }}
tolerations:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.affinity }}
affinity:
  {{- toYaml . | nindent 2 }}
{{- end }}
{{- end -}}
