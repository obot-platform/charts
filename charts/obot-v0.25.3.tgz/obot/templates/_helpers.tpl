{{/*
Return the chart name and version.
*/}}
{{- define "obot.chart" -}}
{{ printf "%s-%s" .Chart.Name .Chart.Version | quote }}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "obot.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a fullname using the release name and the chart name.
*/}}
{{- define "obot.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "obot.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{/*
Create labels for the resources.
*/}}
{{- define "obot.labels" -}}
helm.sh/chart: {{ include "obot.chart" . }}
{{ include "obot.selectorLabels" . }}
{{- with .Chart.AppVersion }}
app.kubernetes.io/version: {{ . | quote }}
{{- end }}
app.kubernetes.io/component: gateway
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: obot
{{- if .Values.additionalLabels }}
{{ toYaml .Values.additionalLabels }}
{{- end }}
{{- end -}}

{{/*
Create selector labels for the resources.
*/}}
{{- define "obot.selectorLabels" -}}
app.kubernetes.io/name: {{ include "obot.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "obot.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "obot.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Set name of secret to use for credentials
*/}}
{{- define "obot.secret.secretName" -}}
{{- if .Values.secret.existingSecret -}}
{{- .Values.secret.existingSecret -}}
{{- else -}}
{{ .Release.Name }}-config
{{- end -}}
{{- end -}}

{{/*
Create the name of the Secret and RBAC resources used to peer tunnel servers.
*/}}
{{- define "obot.tunnelPeerName" -}}
{{- $base := include "obot.fullname" . | trunc 51 | trimSuffix "-" -}}
{{ printf "%s-tunnel-peer" $base }}
{{- end -}}

{{/*
Return the Secret containing the tunnel peer token.
*/}}
{{- define "obot.tunnelPeerSecretName" -}}
{{- if .Values.tunnelPeer.existingSecret -}}
{{- .Values.tunnelPeer.existingSecret -}}
{{- else -}}
{{- include "obot.tunnelPeerName" . -}}
{{- end -}}
{{- end -}}

{{/*
Set name of configmap to use for non-sensitive config
*/}}
{{- define "obot.config.configMapName" -}}
{{ .Release.Name }}-internal-config
{{- end -}}

{{/*
Set name of namespace to use for mcp servers
*/}}
{{- define "obot.config.mcpNamespace" -}}
{{- if .Values.mcpNamespace.name -}}
{{- .Values.mcpNamespace.name -}}
{{- else -}}
{{ .Release.Name }}-mcp
{{- end -}}
{{- end -}}

{{/*
Generate comma-separated list of MCP image pull secret names
*/}}
{{- define "obot.config.mcpImagePullSecrets" -}}
{{- $secrets := list -}}
{{- range .Values.mcpImagePullSecrets -}}
{{- $secrets = append $secrets .name -}}
{{- end -}}
{{- join "," $secrets -}}
{{- end -}}

{{/*
Validate PSA level value. Valid values are: privileged, baseline, restricted
Usage: {{ include "obot.validatePSALevel" (dict "value" .Values.mcpNamespace.podSecurity.enforce "field" "mcpNamespace.podSecurity.enforce") }}
*/}}
{{- define "obot.validatePSALevel" -}}
{{- $validLevels := list "privileged" "baseline" "restricted" -}}
{{- if not (has .value $validLevels) -}}
{{- fail (printf "Invalid PSA level %q for %s: must be one of [privileged, baseline, restricted]" .value .field) -}}
{{- end -}}
{{- end -}}

{{/*
Validate all PSA level values in mcpNamespace.podSecurity
*/}}
{{- define "obot.validatePodSecurityLevels" -}}
{{- if .Values.mcpNamespace.podSecurity.enabled -}}
{{- include "obot.validatePSALevel" (dict "value" .Values.mcpNamespace.podSecurity.enforce "field" "mcpNamespace.podSecurity.enforce") -}}
{{- include "obot.validatePSALevel" (dict "value" .Values.mcpNamespace.podSecurity.audit "field" "mcpNamespace.podSecurity.audit") -}}
{{- include "obot.validatePSALevel" (dict "value" .Values.mcpNamespace.podSecurity.warn "field" "mcpNamespace.podSecurity.warn") -}}
{{- end -}}
{{- end -}}

{{/*
Validate network policy provider Helm chart configuration.
*/}}
{{- define "obot.validateNetworkPolicyProviderChartConfig" -}}
{{- $repo := .Values.config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_REPO | default "" | toString | trim -}}
{{- $name := .Values.config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_NAME | default "" | toString | trim -}}
{{- if and $repo (not $name) -}}
{{- fail "config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_NAME is required when config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_REPO is set" -}}
{{- end -}}
{{- if and $name (not $repo) -}}
{{- fail "config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_REPO is required when config.OBOT_SERVER_MCPNETWORK_POLICY_PROVIDER_CHART_NAME is set" -}}
{{- end -}}
{{- end -}}

{{/*
Get the image tag, defaulting to appVersion. If appVersion looks like a development version (0.0.0-dev),
defaults to "main" tag instead.
*/}}
{{- define "obot.imageTag" -}}
{{- $tag := .Values.image.tag | default .Chart.AppVersion -}}
{{- if and (not .Values.image.tag) (hasPrefix "0.0.0" .Chart.AppVersion) -}}
{{- $tag = "main" -}}
{{- end -}}
{{- $tag -}}
{{- end -}}
